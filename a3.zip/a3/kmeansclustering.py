import numpy as np,csv
from itertools import combinations

np.set_printoptions(suppress=True)
#get the distance of two record actually is the current vs centroid
def distEclud(vecA,vecB):
    return sum((vecA-vecB)**2)**0.5

def randCent(dataset,k):
    # dataset is the raw_data need to be clustered and the k is the number of classes we wanted to cluster to
    n = np.shape(dataset)[1] # the number of attr
    #print("nub of attr : "+ str(n))
    centroids = np.mat(np.zeros([k,n]))
    # random picked between the largest and smallest value in the dataset
    for i in range(n):
        maxi = max(dataset[:,i])
        mini = min(dataset[:,i])
        #fix the cent
        centroids[:,i] = mini + (maxi-mini)*np.random.random([k,1])
        #centroids[:, i] = (mini + maxi)/2

    return centroids


def kmeans0(dataset, k):
    # k is the number of classes we want to be clusterd into
    m = np.shape(dataset)[0]  # the number of records
    clusterAssment = np.mat(np.zeros((m, 2)))  #initialize it, first is the class and the second is the distance
    centroids = randCent(dataset, k)  # get a random centroid
    #print("initial centroids:")
    #print(centroids)
    clusterChanged = True  # to control the iterate times
    while clusterChanged:
        clusterChanged = False  # first time iterate if the result changed then True and continue iterate else stop
        for i in range(m):  # loop every record
            # computer the distance between current record and each centroid
            # find the min distance
            mindist = np.inf
            for j in range(k):  # loop every class
                #print(j)
                #print(dataset[i,:])
                #print(np.array(centroids[j,:])[0])
                distj =distEclud(np.array(dataset[i, :]), np.array(centroids[j,:])[0])
                #print(distj)
                if distj < mindist:
                    mindist = distj
                    minj = j
            # loop all the k cluster and current record has been cluster
            if clusterAssment[i, 0] != minj:  # if different with last iteration that means still have things changed may have chance to change in the next iter so iterate again
                clusterChanged = True  # if any result changed then still in the iteration progress
            clusterAssment[i, :] = minj, mindist ** 2  # first is the class of record and the second is the distance away from the centroid
        # outer loop ended, and every record be clustered
        # update centroid
        for cent in range(k):
            # find out the same class record
            data_cent = dataset[np.nonzero(clusterAssment[:, 0].A == cent)[0]]
            centroids[cent, :] = np.mean(data_cent, axis=0)
    return centroids, clusterAssment

def get_raw_data(filename):
    raw_data = []
    #filename = './processed.cleveland.data'
    with open(filename) as f:
        reader = csv.reader(f)
        for row in reader:
            if '?' in row:
                continue
            raw_data.append(list(map(float, row)))
    # print(len(raw_data))
    raw_data = np.array(raw_data)
    return raw_data

def get_label_binary(raw_data):
    #print(raw_data)
    return_binary_result = []
    for raw in raw_data:
        if int(float(raw[-1]))==0:
            return_binary_result.append(0)
        else:
            return_binary_result.append(1)
    return return_binary_result

def get_label_cluster(clusterAssment):
    return_label_cluster = []
    for nub in clusterAssment[:,0]:
        return_label_cluster.append(int(float(nub)))
    return return_label_cluster


def count_accuracy(a,b):
    count = 0
    for i in range(len(a)):
        if a[i] == b[i]:
            count+=1
    return count/len(a)

# let[1, 0] to be [0, 1]
def reverse_label(b):
    return_b = []
    for nub in b:
        if nub == 0:
            return_b.append(1)
        else:
            return_b.append(0)
    return return_b

def process_data(dataset,need_attr):
    need_attr +=(13,)
    return dataset[:,need_attr]
        
if __name__ == "__main__":
    raw_data = get_raw_data('./processed.cleveland.data')
    max_accuracy = -999
    max_item = []
    max_a = []
    max_b = []

    final_central = []
    a= get_label_binary(raw_data)
    # 2 here means we only want to use 2 attributes for clustering the result
    for item in (list(combinations([0,1,2,3,4,5,6,7,8,9,10,11,12], 2))):
        print(item)
        dataset = process_data(raw_data,item)
        # 2 here means we want 2 centroids we want to classified into 2 classes
        centroids, clusterAssment = kmeans0(dataset,2)
        print("after change centroids: ")
        print(centroids)
        #print("cluster")
        #print(clusterAssment)
        


        b= get_label_cluster(clusterAssment)
        if count_accuracy(a,b)<count_accuracy(a,reverse_label(b)):
            b= reverse_label(b)
        #print(a)
        #print(b)
        print(item)
        current_accuracy = count_accuracy(a,b)
        print(current_accuracy)
        if current_accuracy> max_accuracy:
            max_accuracy = current_accuracy
            max_item = item
            max_b = b
            final_central = centroids
        #break
    print("max_accuracy: " + str(max_accuracy))
    print("max_item: " + str(max_item))
    #print(list(range(len(raw_data[:,1]))))
    #print("center point: " + str(final_central[1]))
    print("center point: " + str(final_central))
    print("raw_label")
    print(a) # raw_label
    print("predict_label")
    print(max_b) # predict_label


