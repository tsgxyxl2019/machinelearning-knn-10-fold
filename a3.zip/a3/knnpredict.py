import csv, operator
import numpy as np
from sklearn.model_selection import KFold


def kfold_split_index(rawdata):  # return a index list use k-fold
    kf = KFold(n_splits=10, shuffle=False)
    index_collection = []
    for train_index, test_index in kf.split(rawdata):
        index_collection.append([train_index, test_index])

        #print('train_index:%s , test_index: %s ' %(train_index,test_index))
    return index_collection


def split_rawdata(rawdata, train_index, test_index):
    train_x = []
    train_y = []
    test_x = []
    test_y = []
    for row in rawdata[train_index]:
        train_x.append(row[:-1])
        train_y.append(str(row[-1]))
    for row in rawdata[test_index]:
        test_x.append(row[:-1])
        test_y.append(str(row[-1]))
    return np.array(train_x), np.array(train_y), np.array(test_x), np.array(test_y)


def classify(testData, dataSet, labels, k):
    dataSetSize = dataSet.shape[0]
    multitestData = np.tile(testData, (dataSetSize, 1))
    # print("multitestData:")
    # print(multitestData)
    diffMat = multitestData - dataSet
    sqdiffMat = diffMat ** 2
    sqdistance = sqdiffMat.sum(axis=1)
    # print(sqdistance)
    distance = sqdistance ** 0.5
    sortedDistIndex = distance.argsort()
    classCount = {}
    for i in range(k):
        voteIlabel = labels[sortedDistIndex[i]]
        classCount[voteIlabel] = classCount.get(voteIlabel, 0) + 1
    sortedClassCount = sorted(classCount.items(), key=operator.itemgetter(1), reverse=True)
    # print(sortedClassCount)
    return sortedClassCount[0][0]


def get_score(train_x, train_y, test_x, test_y, k):
    count = 0
    for i, record in zip(range(0, 1000), test_x):
        #print("record is :" , end = "")
        #print(record)
        #print("shouldbe :" + str(test_y[i]))
        predict = classify(record, train_x, train_y, k)
        if str(predict) == str(test_y[i]):
            #print(predict + " -> " + str(test_y[i]))
            count += 1
        #else:
        #    print(predict + " -> " + str(test_y[i]) + " not correct")
    #print("accuracy is: " ,end="")
    #print(count/len(test_x))
    return count / len(test_x)

# clean the data
def get_raw_data(filename):
    raw_data = []
    #filename = './processed.cleveland.data'
    with open(filename) as f:
        reader = csv.reader(f)
        for row in reader:
            if '?' in row:
                continue
            raw_data.append(list(map(float, row[:-1])))

    # print(len(raw_data))
    raw_data = np.array(raw_data)
    return raw_data

'''
this is the main part for getting the highest accurate rate using knn algorithm
and it will return the train_x,train_y and the k value with that highest accurate score
then we use this train_x set and k for our k-nn algorithm 
'''
def get_kvalue_of_largest_score(raw_data):
    index_collection = kfold_split_index(raw_data)
    # print(index_collection)
    max_score = -999
    max_train_x = []
    max_train_y = []
    max_test_x = []
    max_test_y = []
    max_item = []
    max_i = 0
    max_k = 0
    for i, item in zip(range(0, 10000, 1), index_collection):
        train_x, train_y, test_x, test_y = split_rawdata(raw_data, item[0], item[1])
        for k in range(1, 20):
            # score = get_score(train_x, train_y, test_x, test_y, k)
            score_2 = get_score(train_x, train_y, raw_data[:, :-1], raw_data[:, -1], k)
            # print("max_score:_2 " + str(score_2))  # accuracy
            if score_2 > max_score:
                max_score = score_2
                max_train_x = train_x
                max_train_y = train_y
                max_test_x = test_x
                max_test_y = test_y
                max_item = item
                max_i = i
                max_k = k
                # print("max_k: " + str(max_k))
                # print("max_score: " + str(max_score))
    return max_k, max_score, max_train_x, max_train_y


def predict_lable(test_data, max_k, max_train_x, max_train_y):
    pre_lable = classify(test_data, max_train_x, max_train_y, max_k)
    return pre_lable


if __name__ == "__main__":
    raw_data = get_raw_data('./processed.cleveland.data')
    max_k, max_score, max_train_x, max_train_y=get_kvalue_of_largest_score(raw_data)
    print(max_k)
    print(max_score)
    # print(len(max_train_x))
    # print(len(max_train_y))
    # print(len(raw_data))
    label = predict_lable([41.0,1.0,4.0,110.0,172.0,0.0,2.0,158.0,0.0,0.0,1.0,0.0],max_k,max_train_x,max_train_y)
    print(label)
