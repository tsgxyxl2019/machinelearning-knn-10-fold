'''
Team Name: Teamone
group master:
Student Name:Xinle Yao
Student ID:z5099711
group member
Student Name:Jiaxuan Mu
Student ID:z5190635

Student Name:Shenghan Gao
Student ID:z5095104
'''
import csv,sys,json,os
import pandas as pd
from knnpredict import get_raw_data,predict_lable,get_kvalue_of_largest_score
from kmeansclustering import combinations,process_data,kmeans0,get_label_binary,get_label_cluster,count_accuracy,reverse_label,distEclud
from kmeansclustering import get_raw_data as get_2
from flask import Flask, request,render_template,redirect,url_for,session
import numpy as np
from numpy import *
from sklearn.model_selection import train_test_split

from collections import Counter, defaultdict
import matplotlib
import matplotlib.pyplot as plt

import sqlite3
import os
from sqlite3 import Error
from flask_sqlalchemy import SQLAlchemy
import io
import base64
import urllib.parse
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression

index_correspond_attri = {"chest": 3,"pressure": 4,"cholestoral": 5,"sugar": 6,"electrocardiographic": 7,"rate": 8,"exercise": 9,"oldpeak": 10,"slope": 11,"flourosopy": 12,"thal": 13}
attri_correspond_index = {"3": "chest","4": "pressure","5":"cholestoral","6":"sugar","7":"electrocardiographic",
                          "8":"rate","9":"exercise","10":"oldpeak","11":"slope","12":"flourosopy","13":"thal"}


'''
Create database for storing imgs
'''
basedir = os.path.abspath(os.path.dirname(__file__))
path = basedir + '/data.db'
def create_db(db_file):
    try:
        conn = sqlite3.connect(db_file)
        print(sqlite3.version)
    except Error as e:
        print(e)
    finally:
        conn.close()
if __name__ == '__main__':
    create_db(path)

'''
Add label number
'''
def autolabel(ax, rects, xpos='center'):
    xpos = xpos.lower()  
    ha = {'center': 'center', 'right': 'left', 'left': 'right'}
    offset = {'center': 0.5, 'right': 0.57, 'left': 0.43}  
    for rect in rects:
        height = rect.get_height()
        ax.text(rect.get_x() + rect.get_width()*offset[xpos], 1.01*height,
                '{}'.format(height), ha=ha[xpos], va='bottom')

app = Flask(__name__)
app.config['SECRET_KEY']=os.urandom(24)

''' sqlalchemy db config '''
app.config['JSON_SORT_KEYS'] = False
# Using window path
app.config['SQLALCHEMY_DATABASE_URI'] ='sqlite:///data.db'

#app.config['SQLALCHEMY_DATABASE_URI'] =\
#    'sqlite:////' + os.path.join(basedir, 'data.db')

app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
#
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)

class Dataset(db.Model):
    __tablname__ = 'Dataset'
    id = db.Column(db.Integer, primary_key = True)

    age = db.Column(db.Integer)
    sex = db.Column(db.String(64))
    chest = db.Column(db.String(64))
    pressure = db.Column(db.Integer)
    cholestoral = db.Column(db.Integer)
    sugar = db.Column(db.String(64))
    electrocardiographic = db.Column(db.String(64))
    rate = db.Column(db.Integer)
    exercise = db.Column(db.String(64))
    oldpeak = db.Column(db.Float)
    slope = db.Column(db.Integer)
    flourosopy = db.Column(db.Integer)
    thal = db.Column(db.String(64))
    target = db.Column(db.Integer)

global names, discrete, continuous
names  = ["age", "sex", "chest", "pressure", "cholestoral", "sugar", "electrocardiographic", "rate", "exercise", "oldpeak", \
                                                        "slope", "flourosopy", "thal", "target"]
discrete = ['chest','sugar','electrocardiographic','exercise','thal','slope','flourosopy','target']
continuous = ['pressure','cholestoral','rate','oldpeak']

db.create_all()

def create_dataset():
    data = pd.read_csv("processed.cleveland.data", header = None)
    data = pd.DataFrame(data.values, columns = names)
    data['target'][data['target'] != 0] = 1
    data['target'].replace([0,1],['no','yes'], inplace=True)
    data['sex'].replace([0.0,1.0],['female','male'],inplace=True)
    data['chest'].replace([1.0,2.0,3.0,4.0],['typical angin', 'atypical angina', 'non-anginal pain', 'asymptomatic'],inplace=True)
    data['sugar'].replace([0.0,1.0],['<= 120 mg/dl','> 120 mg/dl'],inplace=True)
    data['electrocardiographic'].replace([0.0,1.0,2.0],['normal','having ST-T wave abnormality', 'showing left ventricular hypertrophy'],inplace=True)
    data['exercise'].replace([0.0,1.0],['no','yes'], inplace=True)
    data['thal'].replace(['3.0','6.0','7.0'],['normal','fixed defect','reversable defect'],inplace=True)
    pid = 1
    
    if db.session.query(Dataset).first() != None:
        return
    for index, row in data.iterrows():
        row.replace('?','NULL', inplace=True)
        pid = pid
        age = row['age']
        sex = row['sex']
        chest = row['chest']
        pressure = row['pressure']
        cholestoral = row['cholestoral']
        sugar = row['sugar']
        electrocardiographic = row['electrocardiographic']
        rate = row['rate']
        exercise = row['exercise']
        oldpeak = row['oldpeak']
        slope = row['slope']
        flourosopy = row['flourosopy']
        thal = row['thal']
        target = row['target']
        D = Dataset(id = pid, age = age, sex = sex, chest = chest, pressure = pressure, cholestoral = cholestoral, sugar = sugar,electrocardiographic = electrocardiographic,
            rate = rate, exercise = exercise, oldpeak = oldpeak, slope = slope, flourosopy = flourosopy, thal = thal, target = target)   
        db.session.add(D)
        db.session.commit()
        pid += 1

@app.route('/', methods=['GET', 'POST'])
def index():
    img_path = []
    create_dataset()
    if request.method == 'POST':
        select = request.form.get('attribute_select')
        select_divide = select.split("-")
        if select_divide[1] == "bar": # user choose the bar graph
            select = select_divide[0]
            index = index_correspond_attri[str(select)]
            img_path.append('/static/images/bar/bar-male-' + str(index) + '.png')
            img_path.append('/static/images/bar/bar-female-' + str(index) + '.png')
            if select in discrete:
                plot_url = visualise(select)
                return render_template('index.html', img_path=img_path, plot_url=plot_url)
            else:
                return render_template('index.html', img_path=img_path)
        else:
            select = select_divide[0]
            index = index_correspond_attri[str(select)]
            img_path.append('/static/images/scatter/scatter-age-' + str(index) + '.png')
            #img_path.append('/static/images/scatter/scatter-sex-' + str(index) + '.png')
            if select in continuous:
                plot_url = visualise(select)
                return render_template('index.html', img_path=img_path, plot_url=plot_url)
            else:
                return render_template('index.html', img_path=img_path)
    return render_template('index.html')
 

@app.route('/predict_thal', methods=['GET', 'POST'])
def predict_thal():
    if request.method == 'POST':
        # do stuff when the form is submitted
        # redirect to end the POST handling
        # the redirect can be to the same route or somewhere else
        predict_data = []
        parameters = request.form
        for parameter in parameters:
            try:
                predict_data.append(float(parameters[parameter]))
            except:
                return "input should be a number or not be empty"
        filename = './processed.cleveland.data'
        raw_data = get_raw_data(filename)
        max_k, max_score, max_train_x, max_train_y = get_kvalue_of_largest_score(raw_data)
        label = predict_lable(predict_data, max_k, max_train_x, max_train_y)
        accurate = format(max_score, '.2%')
        text = "The accuracy rate of the model is: " + str(accurate) + " with using "+ str(max_k) +"nn with 10 fold     cross validation . And the predict label of thal is: " + str(label)
        #return render_template('index.html', img_path=img_path)
        return  render_template('predict_thal.html',text = text)

    # show the form, if it wasn't submitted
    if request.method == 'GET':
        return render_template('predict_thal.html')

@app.route('/predict_heartdisease', methods=['GET', 'POST'])
def predict_heartdisease():
    text = ''
    if request.method == 'POST':
        predict_data = []
        predict_data_2 = []
        parameters = request.form
        for parameter in parameters:
            try:
                predict_data.append(float(parameters[parameter]))
                predict_data_2.append(float(parameters[parameter]))
            except:
                return "input should be a number or not be empty"
        #calculate distance
        print(predict_data)
        x = 1.5
        predict_data.append(float(x))
        predict_data_2.append(float(0))
        m_h = np.matrix(session['happen_mid'])
        m_u = np.matrix(session['unhappen_mid'])
        Happen = distEclud(np.array(predict_data), np.array(m_h[0,:])[0])
        Unhappen = distEclud(np.array(predict_data_2), np.array(m_u[0,:])[0])
        if Happen < Unhappen:
            text = 'Input in happen group'
        else:
            text = 'Input in unhappen group'
        return  render_template('predict_heartdisease.html',text = text)

    # show the form, if it wasn't submitted
    if request.method == 'GET':
        return render_template('predict_heartdisease.html',items = session['items'] )
    
@app.route('/clustering', methods=['GET', 'POST'])
def clustering():
    if request.method == "POST":
        session['items'] = []
        session['happen_mid'] = []
        session['unhappen_mid'] = []
        print(session)
        num = request.form['num_attri']
        print(str(int(num)))
        raw_data = get_2('./processed.cleveland.data')
        max_accuracy = -999
        max_item = []
        max_a = []
        max_b = []
        final_center = []
        a = get_label_binary(raw_data) # get the label list from the raw_data 
        for item in (list(combinations([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], int(num)))):
            dataset = process_data(raw_data, item) # this will give the train set with specific columns, items is the index of specific columns
            # centroids is the centroids after trained and clusterAssment is the format [[A,B],...], [A,B] refer to one record in raw_data,[A] is the  predicted_label and [B] is the distance
            centroids, clusterAssment = kmeans0(dataset, 2) 
            b = get_label_cluster(clusterAssment) # get the label list from the after-predict-data 
            #it may the disclassification like all the label_predicted_0 actually is 1 in the raw_data , so we convert it then compare to get the accuracy
            if count_accuracy(a, b) < count_accuracy(a, reverse_label(b)):
                b = reverse_label(b)
            current_accuracy = count_accuracy(a, b)
            if current_accuracy > max_accuracy:
                max_accuracy = current_accuracy
                max_item = item
                max_b = b
                final_center = centroids
        # this is the part for showing which attributes to show on the webpage
        text_1 = 'Attributes '
        for n in max_item:
            text_1  = text_1 + "'"+names[n] + "'"+ ', '
            session['items'].append(names[n])
        text_1 = text_1 + 'are chosen to be clustered'
        text_2 = 'With center '
        # this means the first_centriod get the heart-disease if its label value larger than the second
        if final_center[0,-1] > final_center[1,-1]:
            text_2 += str(final_center[0]) + '(get_heart-disease), ' + str(final_center[1]) + '(health) '
            session['happen_mid'] = final_center[0][0:].tolist()
            session['unhappen_mid'] = final_center[1][0:].tolist()
        else:
            text_2 += str(final_center[1]) + '(happen), ' + str(final_center[0]) + '(unhappen) '
            session['happen_mid'] = final_center[1][0:]
            session['unhappen_mid'] = final_center[0][0:]
            session['happen_mid'] = final_center[0][0:].tolist()
            session['unhappen_mid'] = final_center[1][0:].tolist()
        print(session)
        text_2 += "and accuracy is: " + str('{:.2%}'.format(max_accuracy))
        # draw a scatter to show
        tx = list(range(len(raw_data[:,1])))
        ty = a
        px = tx
        py = max_b
        fig, ax = plt.subplots(figsize=(10, 10))
        ax.scatter(tx, ty, alpha=0.8, c='red', edgecolors='none', s=30, label='predict')
        ax.scatter(px, py, alpha=0.8, c='blue', edgecolors='none', s=30, label='real')
        plt.legend()
        img = io.BytesIO()
        plt.savefig(img, format='png')  # save figure to the buffer
        data_1 = base64.encodebytes(img.getvalue()).decode()
        plt.close()
        return render_template('clustering.html',text_1 = text_1,text_2 = text_2,plot_url=data_1)
    else:
        return render_template('clustering.html')


@app.route('/important_factors', methods=['GET', 'POST'])
def feature_selection():
    rank = ''
    R = []
    df = pd.read_csv("processed.cleveland.data", names = names)
    df['target'][df['target'] != 0] = 1
    df = df[df. flourosopy != '?']
    df = df[df.thal != '?']
    array = df.values
    X = array[:,0:13]
    Y = array[:,13]
    Y = Y.astype('int')
    model = LogisticRegression()
    rfe = RFE(model, 1)
    fit = rfe.fit(X, Y)
    for i in range(len(names)):
        for j in range(len(fit.ranking_)):
            if fit.ranking_[j] == i:
                R.append(names[j])
    rank = str(R)
    return render_template('important_factors.html', rank=rank)

def clean_data(filename):
    return_data = []
    with open(filename) as f:
        reader = csv.reader(f)
        for row in reader:
            if '?' in row:
                continue
            return_data.append(row)
    return return_data

def divided(data):
    target = []
    attributes = []
    for row in data:
        target.append(int(row[-1]))
        attributes.append(list(map(float, row[:-1])))
    return array(attributes),array(target)

def divided_into_heartdisease(data,label,index_attr,age_or_sex):
    # this function is used to for dividing data into different sets according to their labels in heart-disease field, and only keep the attribute we need to draw 
    label_set = list(set(label))
    label1 =[]
    label1_age_or_sex = []
    label2 =[]
    label2_age_or_sex = []
    label3 =[]
    label3_age_or_sex = []
    label4 = []
    label4_age_or_sex = []
    label5 = []
    label5_age_or_sex = []
    for i in range(len(data)):
        if label[i] == label_set[0]:
            label1.append(data[i][index_attr])
            label1_age_or_sex.append(data[i][age_or_sex])
        if label[i] == label_set[1]:
            label2.append(data[i][index_attr])
            label2_age_or_sex.append(data[i][age_or_sex])
        if  label[i] == label_set[2]:
            label3.append(data[i][index_attr])
            label3_age_or_sex.append(data[i][age_or_sex])
        if  label[i] == label_set[3]:
            label4.append(data[i][index_attr])
            label4_age_or_sex.append(data[i][age_or_sex])
        if  label[i] == label_set[4]:
            label5.append(data[i][index_attr])
            label5_age_or_sex.append(data[i][age_or_sex])
    return label_set,label1,label1_age_or_sex,label2,label2_age_or_sex,label3,label3_age_or_sex,label4,label4_age_or_sex,label5,label5_age_or_sex

def form_data_with_attribute(c,nub):
    age_list = list(set(list(c[:, 0])))
    attr_list = list(set(list(c[:, nub])))
    return_dic_male = {}
    return_dic_female = {}
    for age in age_list:
        for row in c:
            if row[0] == age and row[1]==1: # value in row[1] can divided data based on sex
                if row[0] not in return_dic_male:
                    return_dic_male[age] = [{"attr": row[nub],"count":1}]
                else:
                    switch = 0 
                    for record in return_dic_male[age]:
                        if  record["attr"] == row[nub]:
                            record["count"] +=1
                            switch =1
                            break
                    if switch ==0:
                        return_dic_male[age].append( {"attr": row[nub],"count":1})
            if row[0] == age and row[1]==0:
                if row[0] not in return_dic_female:
                    return_dic_female[age] = [{"attr": row[nub],"count":1}]
                else:
                    switch = 0
                    for record in return_dic_female[age]:
                        if  record["attr"] == row[nub]:
                            record["count"] +=1
                            switch =1
                            break
                    if switch ==0:
                        return_dic_female[age].append( {"attr": row[nub],"count":1})
    return attr_list,age_list,return_dic_male,return_dic_female

def draw_bargraph(age_list,male_data,female_data,c,index_of_attr,attr_list):
    print("now drawing the " + str(index_of_attr+1) + " attr of male group using bar-graph...")
    draw_bar_graph_sex(age_list,male_data,"./static/images/bar/bar-male-"+str(index_of_attr+1)+".png",attr_list,index_of_attr,1)
    print("now drawing the " + str(index_of_attr+1) + " attr of female group using bar-graph...")
    draw_bar_graph_sex(age_list,female_data,"./static/images/bar/bar-female-"+str(index_of_attr+1)+".png",attr_list,index_of_attr,0)

def draw_bar_graph_sex(age_list,data,image_name,attr_list,index_of_attr,sex):
    count_dic = [[0] * len(age_list) for i in range(len(attr_list))]
    for age in data:
        for record in data[age]:
            count_dic[attr_list.index(record['attr'])][age_list.index(age)] += record["count"]
    count_dic=(np.array(count_dic)) # change it into np.array tobe easy summed the bottom value
    #print(count_dic)
    age_list_int = list(map(int, age_list))
    plt.bar(range(len(count_dic[0])), count_dic[0], label=attr_list[0])
    bottom_value = count_dic[0]
    for i in range(1, len(count_dic)):
        plt.bar(range(len(count_dic[0])), count_dic[i], bottom=bottom_value, label=attr_list[i],tick_label=age_list_int)
        bottom_value += count_dic[i]
    plt.legend(loc='upper right', title='attr: ' + str(attri_correspond_index[str(index_of_attr+1)]), shadow=False, fancybox=True,ncol = 4)
    plt.xlabel('age',fontsize=30)
    plt.ylabel('count',fontsize=30)
    plt.xticks(fontsize=20)
    plt.yticks(fontsize=20)
    if sex == 0:
        plt.title('attr: '+ str(attri_correspond_index[str(index_of_attr+1)])+ " of female group",fontsize=30)
    else:
        plt.title('attr: ' + str(attri_correspond_index[str(index_of_attr+1)]) + " of male group",fontsize=30)
    fig = matplotlib.pyplot.gcf()
    fig.set_size_inches(30, 18)
    fig.savefig(image_name, dpi=100)
    plt.close()


def draw_scatter(data_without_label,label,attr_needdraw,age_or_sex):
    label_set,label1,label1_age_or_sex,label2,label2_age_or_sex,label3,label3_age_or_sex,label4,label4_age_or_sex,label5,label5_age_or_sex =  divided_into_heartdisease(data_without_label,label,attr_needdraw,age_or_sex)
    plt.scatter(label1, label1_age_or_sex, s=100, label=label_set[0], c='blue', marker='.', alpha=None,
                edgecolors='white')
    plt.legend()
    plt.scatter(label2, label2_age_or_sex, s=100, label=label_set[1], c='black', marker='^', alpha=None,
                edgecolors='black')
    plt.legend()
    plt.scatter(label3, label3_age_or_sex, s=100, label=label_set[2], c='yellow', marker='v', alpha=None,
                edgecolors='yellow')
    plt.legend()
    plt.scatter(label4, label4_age_or_sex, s=100, label=label_set[3], c='green', marker='*', alpha=None,
                edgecolors='green')
    plt.legend()
    plt.scatter(label5, label5_age_or_sex, s=100, label=label_set[4], c='red', marker='*', alpha=None, edgecolors='red')
    plt.legend()
    if age_or_sex == 0:
        plt.title('attr: ' + str(attri_correspond_index[str(index_of_attr+1)])+ " group by age")
        plt.xlabel(attri_correspond_index[str(attr_needdraw + 1)], fontsize=30)
        plt.ylabel('age', fontsize=30)
        img_name = './static/images/scatter/scatter-age-' + str(attr_needdraw + 1) + '.png'
    else:
        plt.title('attr: ' + str(attri_correspond_index[str(index_of_attr+1)]) + " group by sex")
        plt.xlabel(attri_correspond_index[str(attr_needdraw+1)] ,fontsize = 30)
        plt.ylabel('sex', fontsize=30)
        img_name = './static/images/scatter/scatter-sex-' + str(attr_needdraw + 1) + '.png'

    fig = matplotlib.pyplot.gcf()
    fig.set_size_inches(30, 18)
    fig.savefig(img_name, dpi=100)
    plt.close()


def visualise(attribute):    
    data = db.session.query(Dataset).all()
    Sx_label = []
    Ax_label = [] 
    Tx_label = []
    if attribute in discrete:
        S = {}
        A = {}
        T = {}
        for i in data:
            res = i.__dict__

            if res[attribute] not in S and res[attribute] != 'NULL':
                S[res[attribute]] = {'male': 0, 'female': 0}
                A[res[attribute]] = {'<50': 0, '50-60': 0, '>60': 0}
                T[res[attribute]] = {'yes': 0, 'no': 0}                    
            if res[attribute] != 'NULL':
                if res['sex'] == 'male':
                    S[res[attribute]]['male'] += 1
                elif res['sex'] == 'female':
                    S[res[attribute]]['female'] += 1 
                if res['age'] < 50:
                    A[res[attribute]]['<50'] += 1
                elif res['age'] >= 50 and res['age'] <= 60:
                    A[res[attribute]]['50-60'] += 1
                elif res['age'] > 60:
                    A[res[attribute]]['>60'] += 1
                if res['target'] == 'yes':
                    T[res[attribute]]['yes'] += 1
                elif res['target'] == 'no':
                    T[res[attribute]]['no'] += 1
        male = []
        female = []
        for i in S:
            Sx_label.append(i)
            male.append(S[i]['male'])
            female.append(S[i]['female'])
        young = []
        middle = []
        old = []
        for i in A:
            Ax_label.append(i)
            young.append(A[i]['<50'])
            middle.append(A[i]['50-60'])
            old.append(A[i]['>60'])
        yes = []
        no = []
        for i in T:
            Tx_label.append(i)
            yes.append(T[i]['yes'])
            no.append(T[i]['no'])

        ind1 = np.arange(len(male)) 
        width1 = 0.35  
        ind2 = np.arange(len(middle))
        width2 = 0.25

        fig, (ax1,ax2,ax3) = plt.subplots(nrows=3, ncols=1, figsize=(15,15))
        p1 = ax1.bar(ind1 - width1/2, tuple(male), width1, color='SkyBlue', label='Male')
        p2 = ax1.bar(ind1 + width1/2, tuple(female), width1, color='IndianRed', label='Female')

        p3 = ax2.bar(ind2 - width2, tuple(young), width2, color='Yellow', label='<50')
        p4 = ax2.bar(ind2, tuple(middle), width2, color='Orange', label='50-60')
        p5 = ax2.bar(ind2 + width2, tuple(old), width2, color='Purple', label='>60')

        p6 = ax3.bar(ind1 - width1/2, tuple(yes), width1, color='SkyBlue', label='yes')
        p7 = ax3.bar(ind1 + width1/2, tuple(no), width1, color='IndianRed', label='no')

        ax1.set_ylabel('number of patient')
        ax1.set_title('%s by sex' %attribute)
        ax1.set_xticks(ind1)
        ax1.set_xticklabels(tuple(Sx_label))
        ax1.legend()
        autolabel(ax1, p1)
        autolabel(ax1, p2)

        ax2.set_ylabel('number of patient')
        ax2.set_title('%s by age' %attribute)
        ax2.set_xticks(ind2)
        ax2.set_xticklabels(tuple(Sx_label))
        ax2.legend()
        autolabel(ax2, p3)
        autolabel(ax2, p4)
        autolabel(ax2, p5)

        ax3.set_ylabel('number of patient')
        ax3.set_title('%s by target' %attribute)
        ax3.set_xticks(ind1)
        ax3.set_xticklabels(tuple(Tx_label))
        ax3.legend()
        autolabel(ax3, p6)
        autolabel(ax3, p7)

        #plt.subplots_adjust(left=0.2,right=0.9,bottom=0.1,top=0.9,hspace=0.2)
        img = io.BytesIO()  # create the buffer
        plt.savefig(img, format='png')  # save figure to the buffer
        img.seek(0)  # rewind your buffer
        plot_data = urllib.parse.quote(base64.b64encode(img.read()).decode()) # base64 encode & URL-escape
        
        return plot_data
    elif attribute in continuous:
        S = {'male': {'age': [], attribute: []}, 'female': {'age': [], attribute: []}}
        T = {'yes': {'age': [], attribute: []}, 'no': {'age': [], attribute: []}}
        for i in data:
            res = i.__dict__
            if res[attribute] != 'NULL':
                if res['sex'] == 'male':
                    S['male']['age'].append(res['age'])
                    S['male'][attribute].append(res[attribute])
                elif res['sex'] == 'female':
                    S['female']['age'].append(res['age'])
                    S['female'][attribute].append(res[attribute])
                if res['target'] == 'yes':
                    T['yes']['age'].append(res['age'])
                    T['yes'][attribute].append(res[attribute])
                elif res['target'] == 'no':
                    T['no']['age'].append(res['age'])
                    T['no'][attribute].append(res[attribute])  
        mx = S['male']['age']
        my = S['male'][attribute]
        fx = S['female']['age']
        fy = S['female'][attribute]    
        yx = T['yes']['age']
        yy = T['yes'][attribute] 
        nx = T['no']['age']
        ny = T['no'][attribute]  

        fig, (ax1,ax2) = plt.subplots(nrows=2, ncols=1, figsize=(15,15))
        ax1.scatter(mx, my, alpha=0.8, c='red', edgecolors='none', s=30, label='male')
        ax1.scatter(fx, fy, alpha=0.8, c='blue', edgecolors='none', s=30, label='female')
        ax2.scatter(yx, yy, alpha=0.8, c='green', edgecolors='none', s=30, label='yes')
        ax2.scatter(nx, ny, alpha=0.8, c='pink', edgecolors='none', s=30, label='no')

        #plt.title('%s with age, sex and target' %attribute)
        ax1.set_title("%s with age and sex" %attribute)
        ax2.set_title("%s with age and target" % attribute)

        ax1.set_ylabel(attribute)
        ax1.set_xlabel('age')
        ax2.set_ylabel(attribute)
        ax2.set_xlabel('age')
        plt.legend()

        img = io.BytesIO()  # create the buffer
        plt.savefig(img, format='png')  # save figure to the buffer
        img.seek(0)  # rewind your buffer
        plot_data = urllib.parse.quote(base64.b64encode(img.read()).decode()) # base64 encode & URL-escape
        
        return plot_data
    else:
        return 'invalid keyword on attribute', 404



if __name__ == "__main__":
    '''
    we use two ways for storing imgs one is under the static folder when flask run it first check if all imgs exist if not draw the imgs that dont exists not for all
    the other way is to draw the imgs when the user query and store it in db
    '''
    filename = './processed.cleveland.data'
    static_bar_png =  './static/images/bar'
    a=os.listdir(static_bar_png)
    
    static_scatter_png = './static/images/scatter'
    b = os.listdir(static_scatter_png)

    cleaned_data = clean_data(filename)
    c, d = divided(cleaned_data)

    img_in_static = []
    img_need_draw_list = []
    for item in a:
        item = item.strip(".png")
        img_need_draw = item.split("-")
        #print(img_need_draw)
        img_in_static.append(int(img_need_draw[2]))
    for item in img_in_static:
        if img_in_static.count(item) == 2:
            img_need_draw_list.append(item)
    for index_of_attr in range(2,13):
        if (index_of_attr+1) not in img_need_draw_list:
           attr_list, age_list, male_data, female_data = form_data_with_attribute(c, index_of_attr)
           draw_bargraph(age_list, male_data, female_data, c, index_of_attr, attr_list)
    img_in_static = []
    img_need_draw_list = []
    for item in b :
        item = item.strip(".png")
        img_need_draw = item.split("-")
        img_in_static.append(int(img_need_draw[2]))
    for item in img_in_static:
        if img_in_static.count(item) == 2:
            img_need_draw_list.append(item)
    for index_of_attr in range(2,13):
        if (index_of_attr+1) not in img_need_draw_list:
            print("now drawing the " + str(index_of_attr + 1) + " attr of group by age using scatter...")
            draw_scatter(c, d, index_of_attr, 0)
            print("now drawing the " + str(index_of_attr + 1) + " attr of group by sex using scatter...")
            draw_scatter(c, d, index_of_attr, 1)
    app.run(debug=True, use_reloader=False,port = 7777)

