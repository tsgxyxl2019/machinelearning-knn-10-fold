import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.utils import shuffle
from sklearn.metrics import precision_score, accuracy_score, recall_score
import csv, operator
import numpy as np
from sklearn.model_selection import KFold




def load_iris(iris_path, split_percentage):
    rawdata = []
    with open('./processed.cleveland.data') as f:
        reader = csv.reader(f)
        for row in reader:
            if '?' in row:
                continue
            rawdata.append(list(map(float, row[:-1])))
    train_x = []
    train_y = []
    test_x = []
    test_y = []
    split_point = int(len(rawdata) * split_percentage)
    for row in rawdata[:split_point]:
        train_x.append(row[:-1])
        train_y.append(str(row[-1]))
    for row in rawdata[:split_point]:
        test_x.append(row[:-1])
        test_y.append(str(row[-1]))
    return np.array(train_x), np.array(train_y), np.array(test_x), np.array(test_y)

    # print(len(raw_data))
    raw_data = np.array(raw_data)
    #df = pd.read_csv(iris_path)
    #df = shuffle(df)
    #iris_x = df.drop('species', axis=1).values
    #iris_y = df['species'].values
    # Split iris data in train and test data
    # A random permutation, to split the data randomly

    #split_point = int(len(iris_x) * split_percentage)
    #iris_X_train = iris_x[:split_point]
    #iris_y_train = iris_y[:split_point]
    #iris_X_test = iris_x[split_point:]
    #iris_y_test = iris_y[split_point:]

    return train_x, train_y, test_x, test_y





if __name__ == '__main__':
    csv_file = 'iris.csv'

    # Split the data into test and train parts
    iris_X_train, iris_y_train, iris_X_test, iris_y_test = load_iris(csv_file, split_percentage=0.8)

    # train a classifier
    knn = KNeighborsClassifier()
    knn.fit(iris_X_train, iris_y_train)

    # predict the test set
    predictions = knn.predict(iris_X_test)
    print("confusion_matrix:\n", confusion_matrix(iris_y_test, predictions))
    print("precision:\t", precision_score(iris_y_test, predictions, average=None))
    print("recall:\t\t", recall_score(iris_y_test, predictions, average=None))
    print("accuracy:\t", accuracy_score(iris_y_test, predictions))