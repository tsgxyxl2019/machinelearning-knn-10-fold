import sqlite3
import os
from sqlite3 import Error
from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
import csv
import pandas as pd
from sqlite3 import Error
import numpy as np
import matplotlib.pyplot as plt
import io
import base64
import urllib.parse
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression

basedir = os.path.abspath(os.path.dirname(__file__))
path = basedir + '/data.db'
def create_db(db_file):
    connect = sqlite3.connect('./data.db')
    cursor = connect.cursor()
    try:
        sql = '''create table dataset(
                    id int,
                    age int,
                    sex text,
                    type text,
                    pressure text,
                    serum Integer,
                    sugar String(64),
                    electro String(64),
                    rate Integer,
                    angina String(64),
                    oldpeak Float,
                    slope Integer,
                    vessels Integer,
                    thal String(64),
                    target Integer,
                    PRIMARY KEY (id)
                )'''
        cursor.execute(sql)
        print('build')
    except Error as e:
        print(e)
        pass
    cursor.close()
    pass

''' Add label number '''
def autolabel(ax, rects, xpos='center'):
    xpos = xpos.lower()
    ha = {'center': 'center', 'right': 'left', 'left': 'right'}
    offset = {'center': 0.5, 'right': 0.57, 'left': 0.43}
    for rect in rects:
        height = rect.get_height()
        ax.text(rect.get_x() + rect.get_width()*offset[xpos], 1.01*height,
                '{}'.format(height), ha=ha[xpos], va='bottom')


app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] ='sqlite:///data.db'
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)
global names
names  = ["age", "sex", "type", "pressure", "serum", "sugar", "electro", "rate", "angina", "oldpeak", \
                                                        "slope", "vessels", "thal", "target"]
class Dataset(db.Model):
    __tablname__ = 'Dataset'
    id = db.Column(db.Integer, primary_key = True)
    age = db.Column(db.Integer)
    sex = db.Column(db.String(64))
    type = db.Column(db.String(64))
    pressure = db.Column(db.Integer)
    serum = db.Column(db.Integer)
    sugar = db.Column(db.String(64))
    electro = db.Column(db.String(64))
    rate = db.Column(db.Integer)
    angina = db.Column(db.String(64))
    oldpeak = db.Column(db.Float)
    slope = db.Column(db.Integer)
    vessels = db.Column(db.Integer)
    thal = db.Column(db.String(64))
    target = db.Column(db.Integer)

@app.route('/')
def create_dataset():
    data = pd.read_csv("processed.cleveland.data", header = None)
    data = pd.DataFrame(data.values, columns = names)
    data['sex'].replace([0.0,1.0],['female','male'],inplace=True)
    data['type'].replace([1.0,2.0,3.0,4.0],['typical angin', 'atypical angina', 'non-anginal pain', 'asymptomatic'],inplace=True)
    data['sugar'].replace([0.0,1.0],['<= 120 mg/dl','> 120 mg/dl'],inplace=True)
    data['electro'].replace([0.0,1.0,2.0],['normal','having ST-T wave abnormality', 'showing left ventricular hypertrophy'],inplace=True)
    data['angina'].replace([0.0,1.0],['no','yes'], inplace=True)
    data['thal'].replace(['3.0','6.0','7.0'],['normal','fixed defect','reversable defect'],inplace=True)
    pid = 1
    for index, row in data.iterrows():
        row.replace('?','NULL', inplace=True)
        pid = pid
        age = row['age']
        sex = row['sex']
        type = row['type']
        pressure = row['pressure']
        serum = row['serum']
        sugar = row['sugar']
        electro = row['electro']
        rate = row['rate']
        angina = row['angina']
        oldpeak = row['oldpeak']
        slope = row['slope']
        vessels = row['vessels']
        thal = row['thal']
        target = row['target']
        try:
            D = Dataset(id = pid, age = age, sex = sex, type = type, pressure = pressure, serum = serum, sugar = sugar,electro = electro,
             rate = rate, angina = angina, oldpeak = oldpeak, slope = slope, vessels = vessels, thal = thal, target = target)
            db.session.add(D)
            db.session.commit()
        except:
            pass
        pid += 1
    return

@app.route('/graph/<attribute>')
def visualise(attribute):
    d = ['type', 'sugar', 'electro', 'angina', 'thal', 'slope', 'vessel', 'target']
    c = ['pressure', 'serum', 'rate', 'oldpeak']

    data = db.session.query(Dataset).all()
    label_s = []
    label_a = []
    if attribute in d:
        S = {}
        A = {}
        if attribute == 'target':
            S['yes'] = {'male': 0,'female': 0}
            A['yes'] = {'<50': 0, '50-60': 0, '>60': 0}
        for i in data:
            res = i.__dict__

            if res[attribute] not in S and res[attribute] != 'NULL':
                S[res[attribute]] = {'male': 0, 'female': 0}
                A[res[attribute]] = {'<50': 0, '50-60': 0, '>60': 0}
            if attribute == 'target' and res[attribute] != 'NULL':
                if res['target'] != 0:
                    if res['sex'] == 'male':
                        S['yes']['male'] += 1
                    elif res['sex'] == 'female':
                        S['yes']['female'] += 1
                    if res['age'] < 50:
                        A['yes']['<50'] += 1
                    elif res['age'] >= 50 and res['age'] <= 60:
                        A['yes']['50-60'] += 1
                    elif res['age'] > 60:
                        A['yes']['>60'] += 1
            if res[attribute] != 'NULL':
                if res['sex'] == 'male':
                    S[res[attribute]]['male'] += 1
                elif res['sex'] == 'female':
                    S[res[attribute]]['female'] += 1
                if res['age'] < 50:
                    A[res[attribute]]['<50'] += 1
                elif res['age'] >= 50 and res['age'] <= 60:
                    A[res[attribute]]['50-60'] += 1
                elif res['age'] > 60:
                    A[res[attribute]]['>60'] += 1
        male = []
        female = []
        for i in S:
            label_s.append(i)
            male.append(S[i]['male'])
            female.append(S[i]['female'])
        young = []
        middle = []
        old = []
        for i in A:
            label_a.append(i)
            young.append(A[i]['<50'])
            middle.append(A[i]['50-60'])
            old.append(A[i]['>60'])

        ind1 = np.arange(len(male))
        width1 = 0.35
        ind2 = np.arange(len(middle))
        width2 = 0.25

        fig, (ax1, ax2) = plt.subplots(nrows=2, ncols=1, figsize=(10, 10))
        p1 = ax1.bar(ind1 - width1 / 2, tuple(male), width1, color='SkyBlue', label='Male')
        p2 = ax1.bar(ind1 + width1 / 2, tuple(female), width1, color='IndianRed', label='Female')

        p3 = ax2.bar(ind2 - width2, tuple(young), width2, color='Yellow', label='<50')
        p4 = ax2.bar(ind2, tuple(middle), width2, color='Orange', label='50-60')
        p5 = ax2.bar(ind2 + width2, tuple(old), width2, color='Purple', label='>60')

        ax1.set_ylabel('number of patient')
        ax1.set_title('%s by sex' % attribute)
        ax1.set_xticks(ind1)
        ax1.set_xticklabels(tuple(label_s))
        ax1.legend()
        autolabel(ax1, p1)
        autolabel(ax1, p2)

        ax2.set_ylabel('number of patient')
        ax2.set_title('%s by age' % attribute)
        ax2.set_xticks(ind2)
        ax2.set_xticklabels(tuple(label_s))
        ax2.legend()
        autolabel(ax2, p3)
        autolabel(ax2, p4)
        autolabel(ax2, p5)

        plt.subplots_adjust(left=0.2, right=0.9, bottom=0.1, top=0.9, hspace=0.2)
        plt.show()
        img = io.BytesIO()  # create the buffer
        plt.savefig(img, format='png')  # save figure to the buffer
        img.seek(0)  # rewind your buffer
        plot_data = urllib.parse.quote(base64.b64encode(img.read()).decode())  # base64 encode & URL-escape

        return render_template('test.html', plot_url=plot_data)
    elif attribute in c:
        S = {'male': {'age': [], attribute: []}, 'female': {'age': [], attribute: []}}
        A = []
        B = []
        for i in data:
            res = i.__dict__
            if res[attribute] != 'NULL':
                if res['sex'] == 'male':
                    S['male']['age'].append(res['age'])
                    S['male'][attribute].append(res[attribute])
                elif res['sex'] == 'female':
                    S['female']['age'].append(res['age'])
                    S['female'][attribute].append(res[attribute])
        mx = S['male']['age']
        my = S['male'][attribute]
        fx = S['female']['age']
        fy = S['female'][attribute]

        fig, ax = plt.subplots(figsize=(10, 10))
        ax.scatter(mx, my, alpha=0.8, c='red', edgecolors='none', s=30, label='male')
        ax.scatter(fx, fy, alpha=0.8, c='blue', edgecolors='none', s=30, label='female')
        plt.title('%s with age and sex' % attribute)
        ax.set_ylabel(attribute)
        ax.set_xlabel('age')
        plt.legend()

        img = io.BytesIO()  # create the buffer
        plt.savefig(img, format='png')  # save figure to the buffer
        img.seek(0)  # rewind your buffer
        plot_data = urllib.parse.quote(base64.b64encode(img.read()).decode())  # base64 encode & URL-escape

        return render_template('test.html', plot_url=plot_data)
    else:
        return 'invalid keyword on attribute', 404







if __name__ == '__main__':

    create_db(path)
    app.run(debug=True)