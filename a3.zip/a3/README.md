# comp9321ass3 Group Project: Heart Disease

Teamone 

z5099711  Xinle Yao

z5190635  Jiaxuan Mu

z5095104  Shenghan Gao

1) To run the web app, after installations of requirement pages mentioned in "requirements.txt", simply use python to run the "a3.py" file. It is optional to delete the "data.db" file every time before running, then go to the localhost port 5000 (http://127.0.0.1:7777/) to see the app.
2) For 'thal' predication, just fill in each attribute with corresponding value and hit sumbit. We used K - Nearest Neighbor Method with K-fold cross-validation. We also include k means clustering of using 1-4 attributes and use these attribute to predict heart disease.
